fun main(){
    var name = "Nazira"

    println(name)
    var surname = "Isabaeva"

    println(surname)

}