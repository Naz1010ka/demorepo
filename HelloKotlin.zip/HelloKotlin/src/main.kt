fun main(){
    val name: String = "Kotlin"
    println(name)

}